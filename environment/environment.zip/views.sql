/* View that relates the article's slug and author */
CREATE VIEW authorship AS
    SELECT articles.slug AS article, authors.name AS author
    FROM authors, articles
    WHERE articles.author = authors.id;

/* View that relates the number of a given HTTP request status per day */
CREATE VIEW DailyStatus AS
    SELECT TO_CHAR(time, 'month DD, YYYY') AS day,
        COUNT(status)::float AS tStatus
    FROM log
    GROUP BY day;

/* View that relates the number of 404 HTTP request status per day */
CREATE VIEW DailyStatusErr AS
    SELECT TO_CHAR(time, 'month DD, YYYY') AS day,
        COUNT(status)::float AS tStatusErr
    FROM log
    WHERE status LIKE '%404%'
    GROUP BY day;