#!/bin/bash
psql -d news -f environment/newsdata.sql
psql -d news -f environment/views.sql
